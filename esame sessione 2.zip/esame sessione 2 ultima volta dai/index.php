<?php
$nome = $cognome = $telefono = $email = $messaggio = "";
$nome_err = $cognome_err = $telefono_err = $email_err = $messaggio_err = $success_message = "";
$developer_info = "Benvenuti nel mio portfolio! Sono un web designer appassionato di creare esperienze digitali uniche.";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $nome = test_input($_POST["nome"]);
    $cognome = test_input($_POST["cognome"]);
    $telefono = test_input($_POST["telefono"]);
    $email = test_input($_POST["email"]);
    $messaggio = test_input($_POST["messaggio"]);

    if (empty($nome)) {
        $nome_err = "Il nome è richiesto.";
    } elseif (!preg_match("/^[a-zA-Z-' ]{3,25}$/", $nome)) {
        $nome_err = "Il nome può contenere solo lettere, spazi, apostrofi e trattini.";
    }

    if (empty($cognome)) {
        $cognome_err = "Il cognome è richiesto.";
    } elseif (!preg_match("/^[a-zA-Z-' ]{3,25}$/", $cognome)) {
        $cognome_err = "Il cognome può contenere solo lettere, spazi, apostrofi e trattini.";
    }

    if (empty($telefono)) {
        $telefono_err = "Il numero di telefono è richiesto.";
    } elseif (!preg_match("/^[0-9]{1,15}$/", $telefono)) {
        $telefono_err = "Il numero di telefono può contenere solo numeri e deve avere massimo 15 caratteri.";
    }

    if (empty($email)) {
        $email_err = "L'indirizzo email è richiesto.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_err = "Formato email non valido.";
    }

    if (empty($messaggio)) {
        $messaggio_err = "Il messaggio è richiesto.";
    } elseif (!preg_match("/^[a-zA-Z0-9\s.,?!'-]+$/", $messaggio)) {
        $messaggio_err = "Il messaggio può contenere solo caratteri alfanumerici, spazi e segni di punteggiatura.";
    }

    if (empty($nome_err) && empty($cognome_err) && empty($telefono_err) && empty($email_err) && empty($messaggio_err)) {
        // Inizializza $form_data come un array vuoto
        $form_data = array();
    
        // Popola $form_data con i valori dei campi del modulo
        $form_data['nome'] = $nome;
        $form_data['cognome'] = $cognome;
        $form_data['telefono'] = $telefono;
        $form_data['email'] = $email;
        $form_data['messaggio'] = $messaggio;
    
        // Salva i dati del modulo nel file JSON
        $json_data = json_encode($form_data, JSON_PRETTY_PRINT);
        file_put_contents('form_data.json', $json_data);
    
        // Mostra il messaggio di successo
        $success_message = "Messaggio inviato con successo!";
    }
}
?>
<html> 
    <header>
        <div class="header-content">
            <div class="name">Mattia's space</div>
            <nav>
                <ul>
                    <li><a href="#chi-sono">Chi Sono</a></li>
                    <li><a href="#servizi-offerti">Servizi Offerti</a></li>
                    <li><a href="#contattami-form">Contattami</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section id="chi-sono">
        <p>Ciao, sono Mattia, il creatore di questo spazio. Esplora la mia crescita come sviluppatore web!</p>

        <!-- Box con immagine e descrizione -->
        <div class="work-box">
            <div class="description">
                <h2>Il Mio Lavoro</h2>
                <p>Ciao, sono Mattia, un web developer di 21 anni. Nel mio percorso, ho creato siti web coinvolgenti, concentrandomi sull'esperienza utente impeccabile. Dalla realizzazione di semplici siti informativi a progetti più complessi, adotto linguaggi diversi per garantire design e funzionalità efficaci. Ogni pagina nel mio portfolio rappresenta un tassello nel mio percorso di apprendimento. Attraverso un approccio attento ai dettagli, cerco di creare siti web esteticamente gradevoli, intuitivi e facili da navigare. Esplorando il mio lavoro, coglierai la mia passione per creare esperienze digitali coinvolgenti.</p>
            </div>
            <img src="immagini/foto-descrizione-lavoro.jpeg" alt="Descrizione dell'immagine">
        </div>
    </section></html>
<?php
// Carica il contenuto JSON dal file
$jsonData = file_get_contents('contenuto.json');

// Decodifica il JSON in un array associativo
$data = json_decode($jsonData, true);

// Verifica se la decodifica JSON ha avuto successo
if ($data === null) {
    die('Errore durante la decodifica JSON');
}
// Estrai l'HTML dal tuo array
$htmlContent = $data['html'];

// Il resto del tuo codice HTML
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mattia's space</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php echo $htmlContent; ?>
</body>
<footer>
    <form id="contattami-form" action=index.php method="post" class="vertical-form">
        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" value="<?php echo isset($nome) ? $nome : ''; ?>" required>
            <span class="error"><?php echo $nome_err; ?></span>
        </div>

        <div class="form-group">
            <label for="cognome">Cognome:</label>
            <input type="text" name="cognome" value="<?php echo isset($cognome) ? $cognome : ''; ?>" required>
            <span class="error"><?php echo $cognome_err; ?></span>
        </div>

        <div class="form-group">
            <label for="telefono">Telefono:</label>
            <input type="tel" name="telefono" value="<?php echo isset($telefono) ? $telefono : ''; ?>" required>
            <span class="error"><?php echo $telefono_err; ?></span>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo isset($email) ? $email : ''; ?>" required>
            <span class="error"><?php echo $email_err; ?></span>
        </div>

        <div class="form-group">
            <label for="messaggio">Messaggio:</label>
            <textarea name="messaggio" rows="2" required><?php echo isset($messaggio) ? $messaggio : ''; ?></textarea>
            <span class="error"><?php echo $messaggio_err; ?></span>
        </div>

        <button type="submit">Invia</button>
    </form>
    <?php if (empty($nome_err) && empty($cognome_err) && empty($telefono_err) && empty($email_err) && empty($messaggio_err) && !empty($success_message)) : ?>
        <div class="success-message" id="successo"><?php echo $success_message; ?></div>
    <?php endif; ?>
    <aside class="developer-info">
            <p><?php echo $developer_info; ?></p>
            <p>Contattami: <a href="mailto:rbosio6@gmail.com">rbosio6@gmail.com</a></p>
        </aside>
        <div class="copyright">
        <p>&copy; 2024 mattia's space. Tutti i diritti riservati.</p>
    </div>
</footer>

</html>

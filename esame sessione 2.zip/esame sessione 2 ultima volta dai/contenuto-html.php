<?php
$htmlContent = <<<HTML
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mattia's space</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <div class="header-content">
            <div class="name">Mattia's space</div>
            <nav>
                <ul>
                    <li><a href="#chi-sono">Chi Sono</a></li>
                    <li><a href="#servizi-offerti">Servizi Offerti</a></li>
                    <li><a href="#contattami-form">Contattami</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section id="chi-sono">
        <p>Ciao, sono Mattia, il creatore di questo spazio. Esplora la mia crescita come sviluppatore web!</p>

        <!-- Box con immagine e descrizione -->
        <div class="work-box">
            <div class="description">
                <h2>Il Mio Lavoro</h2>
                <p>Ciao, sono Mattia, un web developer di 21 anni. Nel mio percorso, ho creato siti web coinvolgenti, concentrandomi sull'esperienza utente impeccabile. Dalla realizzazione di semplici siti informativi a progetti più complessi, adotto linguaggi diversi per garantire design e funzionalità efficaci. Ogni pagina nel mio portfolio rappresenta un tassello nel mio percorso di apprendimento. Attraverso un approccio attento ai dettagli, cerco di creare siti web esteticamente gradevoli, intuitivi e facili da navigare. Esplorando il mio lavoro, coglierai la mia passione per creare esperienze digitali coinvolgenti.</p>
            </div>
            <img src="immagini/foto-descrizione-lavoro.jpeg" alt="Descrizione dell'immagine">
        </div>

        <!-- Box con link a lavori svolti -->
        <div class="portfolio-box">
            <h2>I miei ultimi lavori</h2>
            <div class="portfolio-links">
                <a href="progetto.html" target="_blank">
                    <img src="immagini/immagine-link2.png" alt="Descrizione lavoro 1" class="linkz">
                </a>
                <a href="progetto.html" target="_blank">
                    <img src="immagini/immagine-link2.png" alt="Descrizione lavoro 1" class="linkz">
                </a>
                <a href="progetto.html" target="_blank">
                    <img src="immagini/immagine-link2.png" alt="Descrizione lavoro 1" class="linkz">
                </a>
                <a href="progetto.html" target="_blank">
                    <img src="immagini/immagine-link2.png" alt="Descrizione lavoro 1" class="linkz">
                </a>
                <a href="progetto.html" target="_blank">
                    <img src="immagini/immagine-link2.png" alt="Descrizione lavoro 1" class="linkz">
                </a>
                <!-- Aggiungi altri link e immagini secondo necessità -->
            </div>
        </div>
    </section>

    <section id="servizi-offerti">
    <h2>Servizi Offerti</h2>
    <p>Sviluppo web su misura, design responsive, ottimizzazione SEO, integrazione CMS, gestione hosting, manutenzione periodica, sicurezza, e-commerce, supporto tecnico, consulenza personalizzata.</p>
    <!-- Aggiungi ulteriori dettagli o elenchi dei servizi offerti -->
</section>

</body>
</html>

HTML;

$jsonContent = json_encode(['html' => $htmlContent], JSON_PRETTY_PRINT);
file_put_contents('contenuto.json', $jsonContent);
?>
